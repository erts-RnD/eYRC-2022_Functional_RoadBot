defmodule FB_HardwareTestingTest do
  use ExUnit.Case
  doctest FB_HardwareTesting

  test "greets the world" do
    assert FB_HardwareTesting.hello() == :world
  end
end
